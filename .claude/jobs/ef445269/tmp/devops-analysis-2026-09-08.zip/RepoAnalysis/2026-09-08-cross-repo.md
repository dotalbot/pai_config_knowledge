---
title: The estate — all repos, and how work is actually conducted
date: 2026-09-08
type: analysis
tags: [inform, devops, repo-analysis, ways-of-working, estate]
source: Azure DevOps / The-Inform-Team
---

# The estate — all repos, and how work is actually conducted

The common thread: **work is organised around individuals, not teams, and
Azure DevOps is being used as storage rather than as a delivery system.** Two
people own the entire estate between them with almost no overlap, 12 of 16
active repos are built for AI assistants to read, and there is not a single
registered pipeline or required-reviewer policy in the whole organisation.

> Scan of 2026-09-08. 17 repos across 2 projects. Commit samples capped at 500.

## The estate by intent

```mermaid
mindmap
  root((The-Inform-Team))
    Delivery
      Digital solutions team
      PowerPlatform_DEV
      Marketing App
      My Inform App
    Knowledge
      Client work
      Copilot Knowledge Base
      PP architecture and DevOps
      Dataverse architecture planning
    Enablement
      Microsoft certifications
      GitHub Copilot Upskilling
      InformSanity
    Client
      Quilter
      Inform website and Svelte
    Experiment
      Tom testing
      Azure Container Apps and MCP
      DevOps Playground
    Personal
      DominicTalbot
```

## Activity: three live, thirteen quiet

| Status | Repos |
|---|---|
| **Live** (< 30 days) | PowerPlatform_DEV (4d), Client work (6d), Digital solutions team (11d) |
| **Recent** (30–90 days) | DominicTalbot (32d), PP architecture and DevOps (41d), Microsoft certifications (60d), Copilot Knowledge Base (61d) |
| **Dormant** (> 150 days) | Marketing App, Dataverse architecture planning, My Inform App, InformSanity, Inform website/Svelte, GitHub Copilot Upskilling, Quilter, Tom testing, Azure Container Apps and MCP |
| **Empty** | DevOps Playground |

Dormancy here mostly means *finished*, not neglected. `Microsoft certifications`
and `GitHub Copilot Upskilling` are enablement material that stops when the
learning stops. The ones worth a second look are `Dataverse architecture
planning` and `PP architecture and DevOps` — architecture thinking that went
quiet while the delivery repos it should inform kept moving.

## Who works where

```mermaid
flowchart LR
    TC["Thomas Capaldi<br/>(2 commit identities)"]
    JB["Jake Boraston"]
    DT["Dominic Talbot"]
    AB["Automatic Build"]

    TC --> CW["Client work<br/>51%"]
    JB --> CW
    JB --> DST["Digital solutions team<br/>77%"]
    AB --> DST
    JB --> PPD["PowerPlatform_DEV<br/>100%"]
    JB --> IS["InformSanity<br/>100%"]
    TC --> K["8 further repos<br/>100% each"]
    DT --> DTR["DominicTalbot<br/>97% — template README"]

    style CW fill:#052e16,stroke:#22c55e,color:#86efac
    style DTR fill:#450a0a,stroke:#ef4444,color:#fca5a5
    style K fill:#0f172a,stroke:#6366f1,color:#a5b4fc
```

**`Client work` is the only genuinely shared repo in the estate** — Thomas 51%,
Jake 48.5%. Everywhere else, one person holds 95–100% of the commits. Thomas is
sole author of eight repos; Jake of two more.

That is a bus-factor finding on `Digital solutions team` in particular: 260MB of
Dynamics solutions, operational PowerShell and flow-triage runbooks, 77% written
by one person.

**Identity hygiene.** Thomas commits as both `thomas-capaldi` and
`Thomas Capaldi`. Any contributor report that doesn't fold these will show two
people and halve each share. Worth fixing at source in his git config.

## How work moves: convention, not policy

This is the heart of it. Three findings that only appear when you look above the
repo layer.

**There are no pipelines registered.** Zero build definitions and zero builds
across both projects. Yet `Digital solutions team` contains authored pipeline
YAML — `Dynamics - Sandbox to SOURCE.yml`, `Inform - DEV to SOURCE (Split Canvas
App).yml` — using Power Platform Build Tools and a service principal, each set
to `trigger: none`. The automation is written but not wired up; it runs when
someone runs it.

**There is one branch policy in the entire organisation, and it restricts file
size.** No minimum-reviewer policy, no build validation, no work-item linking.

```mermaid
flowchart TD
    A["Branch<br/>feat/*, ofgem/*, JakeDEV"] --> B["PR to main"]
    B --> C{"Policy gate?"}
    C -->|"file size only"| D["Merge"]
    D --> E["main"]
    E --> F{"Pipeline?"}
    F -->|"trigger: none<br/>run by hand"| G["Solution artefacts"]
    style C fill:#450a0a,stroke:#ef4444,color:#fca5a5
    style F fill:#451a03,stroke:#f59e0b,color:#fcd34d
    style E fill:#052e16,stroke:#22c55e,color:#86efac
```

Across the estate: **119 PRs, 41 showing a reviewer — and the reviewer is
usually the author.** Peer review by a second person is close to nonexistent.
Since nothing enforces it, this is a settled working style rather than a lapse.

**Branch naming is personal, not organisational.** Thomas uses domain topics
(`ofgem/agent-release-notes`), Jake uses conventional commits in one repo
(`feat/iris-people-export`) and a personal branch in another (`JakeDEV`).
Both are reasonable; neither is agreed.

## The AI layer is the real house style

**12 of 16 non-empty repos carry `CLAUDE.md`, `.claude/`, or `GEMINI.md`.**

| Repo | Agent files |
|---|---|
| Client work | `.claude`, `CLAUDE.md` |
| Digital solutions team | `.claude`, `CLAUDE.md`, `GEMINI.md` |
| InformSanity | `.claude`, `CLAUDE.md`, `GEMINI.md` |
| Copilot Knowledge Base | `.claude`, `CLAUDE.md` |
| My Inform App | `.claude`, `CLAUDE.md` |
| Inform website / Svelte | `.claude`, `CLAUDE.md` |
| PP architecture and DevOps | `.claude` |
| Quilter | `.claude` |
| Microsoft certifications, Marketing App, Dataverse planning, GitHub Copilot Upskilling | `CLAUDE.md` |

`Client work` goes furthest: its README states it is "built to be read and worked
in by Claude Code as much as by people", with nested `CLAUDE.md` files at each
level carrying client constraints, licensing traps and documented dead ends, plus
a root file defining a written house voice for AI-authored documentation.

Where convention exists in this organisation, it is expressed as agent context
rather than as DevOps policy. That is the single most distinctive thing about
how this team works.

## The Azure DevOps setup itself

| Aspect | State |
|---|---|
| Projects | 2 — `Digital solutions team` (the working org), `DevOps Playground` (empty, "a playground project for Dominic Talbot") |
| Teams | 7 in the main project: OLD Backlog, Digital solutions team, Sales and client delivery, Capability build and GTM, ADD - The Digital NEST, The Inform Team website, Agent use cases |
| Iterations | None configured on the main project; 6 sprints defined in the empty Playground |
| Pipelines | None registered; YAML authored in-repo with `trigger: none` |
| Branch policies | One, file-size restriction |
| Repos | 17, of which 3 are live |

The team names describe **business streams, not products** — sales and delivery,
capability build and go-to-market, agent use cases. Backlogs are organised the
way the business talks about itself, while repos are organised the way
individuals work. Those two structures do not meet anywhere in the tooling.

The main project has no sprint iterations, while the empty playground has six.
Whoever set up cadence tooling did it in the sandbox and it never moved across.

## What the thread implies

**DevOps is the filing cabinet, not the factory.** Source control is used
properly — branches, PRs, sensible messages — but everything downstream of the
merge is manual. The capability to automate exists in the repo and is switched
off.

**The team is two specialists working in parallel, not a team working together.**
Thomas owns knowledge and architecture; Jake owns solutions and delivery. They
meet in exactly one repo. Nothing is wrong with that at this size, but it means
no one is reviewing anyone, and each stream's knowledge lives with one person.

**AI-readiness is ahead of DevOps maturity.** This organisation has invested more
in making its repos legible to language models than in making its pipelines run.
That is an unusual and genuinely interesting position — and it means the fastest
route to delivery maturity is probably to encode the missing process as policy,
since the appetite for encoding *context* is clearly already there.

---

### Gaps in this analysis

Read-only PAT scopes limited what could be checked. **Work Items, Release
definitions and Service Connections returned 403.** So backlog structure, sprint
practice and the actual state of that service principal are unverified — the
conclusion that "boards are business-stream shaped" rests on team names alone.
Adding Work Items (Read) to the PAT would close the largest of these.
