---
title: The engineering standard — Darach's proposal against what the repos already do
date: 2026-09-08
type: whitepaper
status: draft for review
tags: [inform, devops, engineering, ways-of-working, evaluations, alm, whitepaper]
source: Client work repo + Darach proposal 7 Sept + org scan 8 Sept
---

# The engineering standard

**Darach's proposal against what the repos already do.**

---

## TL;DR

Darach proposed an AI-assisted delivery standard on 7 September. Read against
what is actually in the repos, **much of it is already documented and partly
evidenced on Ofgem** — agent-readable context files, evaluation sets as
version-controlled source, a Git-integrated ALM loop with two human gates, and a
board hierarchy at the client. This is not a greenfield proposal; it is a second,
independent arrival at much of the same design.

**Read the evidence column before acting on any row.** Only the evaluation work
is backed by an artefact of something actually running — a dated export of real
grader results. The ALM and context-file claims rest on documents describing a
process, and one of those documents, the ALM rollback runbook, says plainly that
it has never been executed end to end and that a desk review found parts of it
overstated. "Written down" and "running" are different claims and this document
tries hard not to blur them.

Three things genuinely do not line up, and they are where the work is:

1. **The repo-to-board bridge does not exist.** Darach's mapping skill is
   unbuilt. On the Inform side there is no join at all — IRIS dominates commits
   in the largest repo and appears in no work item.
2. **Nothing is enforced.** Zero registered pipelines and one branch policy (file
   size) across the whole org. Every good practice in the Ofgem repo is
   convention, held by two people.
3. **The two proposals disagree about where tickets live**, and that
   disagreement is unresolved rather than settled.

The fastest useful move is not to build anything new. It is to **lift the Ofgem
practice into a written standard**, because it is proven, then close the three
gaps in order.

One caution running through this document: the Ofgem material is strong but it
is **one client, one platform, and very recent**. `Client work` is genuinely
shared (Jake 163 commits, Thomas 173), but the evaluation work specifically is
Jake's — 17 of 20 eval commits, all between 20 and 28 August 2026. Treating three
weeks of one engagement as the house standard is a judgement call, not an
obvious inference.

---

## High level: the line-up

```mermaid
flowchart LR
    subgraph P["DARACH PROPOSES"]
        P1["Bridgehead + bootstrap prompts"]
        P2["Tickets in the repo"]
        P3["Agent context files"]
        P4["Evals vs unit tests"]
        P5["QA before UAT"]
        P6["Governed ALM + release gates"]
        P7["Mapping skill to the board"]
        P8["Component library"]
    end
    subgraph R["REPOS ALREADY DO"]
        R1["CLAUDE.md layering, 12 of 16 repos"]
        R2["Eval sets as solution source"]
        R3["Git integration, two human gates"]
        R4["Board hierarchy at the client"]
        R5["Caveats diary for agents"]
    end
    P3 ==> R1
    P4 ==> R2
    P6 ==> R3
    P5 ==> R2
    P2 -.->|"conflicts"| R4
    P7 -.->|"missing both sides"| R4
    P1 -.->|"no equivalent"| R5
    P8 -.->|"nothing exists"| R5

    style R2 fill:#052e16,stroke:#22c55e,color:#86efac
    style R3 fill:#451a03,stroke:#f59e0b,color:#fcd34d
    style R1 fill:#334155,stroke:#94a3b8,color:#e2e8f0
    style P7 fill:#450a0a,stroke:#ef4444,color:#fca5a5
    style P8 fill:#450a0a,stroke:#ef4444,color:#fca5a5
```

**Evidence key.** ● observed artefact of something running · ◐ process
documented, execution unverified · ○ file exists, effectiveness unknown.

| Darach proposes | Repo reality | Verdict | Ev. |
|---|---|---|---|
| Evals for probabilistic, unit tests for deterministic | Eval sets as solution source, three sets on FIT, dated baseline results CSV | **Lines up, and further ahead** | ● |
| QA before formal UAT | Evals run in development against a baseline | **Lines up in principle**, agent behaviour only | ● |
| Governed ALM with release gates | Power Platform Git integration, one branch per solution, Pull then Publish | **Documented, unproven** — rollback never run end to end, desk review found it overstated | ◐ |
| Agent context files (AGENTS.md, CONTEXT.md, ADRs) | `CLAUDE.md` layering in 12 of 16 active repos | **Present** — existence measured, usage quality not | ○ |
| Skills and bounded loops | `writing-review` skill in the repo; documented build sequences | **Partially** — exists, not generalised | ○ |
| Tickets live in the repo | Client board has Agent → Feature → PBI → Feedback | **Conflicts** — see below |
| Mapping skill, repo to Azure DevOps via MCP | Nothing. No join on either side | **Missing** |
| Governed component library | `system-topic-templates/` — 11 reusable templates with a documented substitution procedure | **Partially** — a seed exists, not a library |
| Bridgehead and bootstrap prompts | No equivalent; setup is documented prose, not scripted | **Missing** |
| Measured hypervelocity (lead time, rework, reuse) | Nothing measured anywhere | **Missing** |

---

## Low level: what lines up

### Evaluations — ahead of the proposal

Darach asks for a formalised split between unit tests and evals. The Ofgem repo
has already implemented the eval half and gone further than the proposal
describes.

Test sets export as ordinary botcomponents with YAML bodies: a set is
`componenttype` 19, `kind: EvaluationSet`, carrying the graders; each case is
`kind: EvaluationData` linked by `parentbotcomponentid`. Because graders,
thresholds, expected keywords and expected tool calls all live in the YAML, the
whole set is diffable and reviewable. The CSV import route carries only
`question` and `expectedResponse`, which is why the UI forces reconfiguration
after every import.

`ExpectedToolCallStep` asserts the agent actually invoked a named action. That
is a behavioural assertion, not a text comparison, and it is the thing that
makes an eval a gate.

Evidence exists: `results-260827-1532-baseline.csv` carries `conversationId`,
question, expected, actual, and per-grader result, score and explanation.

### ALM — a different mechanism reaching the same place

Darach proposes a release pipeline with human gates. The repo already runs the
Power Platform Git integration: one dedicated branch per solution, sync commits
straight to it with no PR, and **two human gates between a push and a user
seeing anything** — Check for updates pulls into the environment, publishing is
a separate step.

Three traps are documented, each having cost about a day: connection references
are environment-specific and Dataverse rejects the entire save if one is
missing; the Git integration writes CRLF so solution folders need a `-text`
exemption; and the VS Code extension is a separate mechanism needing its own
clone rather than a view onto the sync folder.

### Agent context — settled practice, not a proposal

`Client work`'s README states it is "built to be read and worked in by Claude
Code as much as by people", with `CLAUDE.md` at each meaningful level carrying
client constraints, licensing traps and documented dead ends. `Copilot Studio
Build Caveats.md` opens by addressing the assistant directly: read this before
proposing a fix, because several entries look like logic bugs but are platform
behaviours.

Any recommendation that treats `CLAUDE.md` layering as new would be arguing a
point already won. That is one element of Darach's proposal, not the whole of it.

### What convergence actually means here

An earlier draft of this document framed the proposal as "a second, independent
arrival at the same design", which reads as a discount. It should not be. Two
engineers reaching a similar shape without coordinating is **convergent
validation** — evidence the design is right, not evidence the second arrival was
redundant.

Four things in the proposal have no Ofgem equivalent at all, and they are not
peripheral:

- **A general-purpose harness.** Everything Ofgem proves is Copilot Studio
  specific — `componenttype 19`, `mspva_<guid>` folders, Power Platform Git sync.
  Darach's bootstrap is platform-agnostic by design and trims itself per project.
- **Production versus artefact.** Good docs in 12 repos is a static asset built
  by hand, repo by repo. A bootstrap prompt is a machine that manufactures that
  asset on demand for the 13th and 14th. Those are different capabilities.
- **Cost control.** Model routing has no counterpart anywhere in the estate, and
  the failure it prevents has already happened — an unrouted setup "deployed 50
  versions of Fable" and consumed his credits in 15 minutes.
- **The deterministic test layer.** Evals grade probabilistic agent responses.
  They say nothing about whether a button works. Playwright and PowerShell
  regression testing covers a defect class evals structurally cannot reach.

Add measurement, where the repo evidence is zero, and the honest summary is that
Darach solved three problems Ofgem's authors never addressed.

### The generalisation path is already anticipated

Worth noting against the survivorship-bias objection: the repo already separates
client-agnostic material from client-specific. Its README lists four **platform
guides** — source control and tooling, system topics, Teams output formatting,
the caveats diary — and states plainly that they are "filed under Ofgem because
that's where the Copilot Studio work is. They aren't Ofgem-specific and should
move if a second client's agents land elsewhere."

Only `alm-rollback-runbook.md` is marked Ofgem-specific. The README also records
a general rule for what cannot be reused: the OGC Knowledge Hub agent is absent
because its value is mostly the client content it points at, so "document the
pattern in a platform guide and skip the solution."

That is a repo that has already thought about what generalises. It does not
prove the guides *do* generalise — that needs a second client — but it means
lifting them into a standard is following the authors' stated intent rather
than over-reading a single engagement.

---

## Low level: what does not line up

### 1. Where tickets live — an unresolved disagreement

Darach's model puts the ticket in the repo, with a mapping skill distilling it
outward to the board. The Ofgem practice runs a real board hierarchy at the
client: `Agent` (permanent, one per agent, never versioned) → `Feature` (one
release train, named `<Agent name>: vNN`) → `PBI` (one change) → `Feedback`
(what a tester raised in UAT). There is a custom `AI_agent_delivery` process
behind it.

Erica's rule from her 1:1 the same day is that **Features are the unit of value
and prioritisation** — "we don't want to see the everyday PBIs".

These three views are not automatically compatible. If tickets live in the repo
and only distilled items surface, then what counts as a Feature, and who decides
the granularity, becomes the contract between engineering and PM. Nobody has
written that contract.

### 2. Nothing is enforced

Across the org: **zero registered build definitions, zero builds, one branch
policy — a file-size restriction.** No minimum-reviewer policy, no build
validation, no work-item linking. Of 119 PRs, 41 show a reviewer and the
reviewer is usually the author.

The pipeline YAML in `Digital solutions team` is authored with `trigger: none`.
The capability exists on paper and runs by hand.

So every good practice described above is convention held by individuals. That
is not a criticism of the individuals; it is a statement about what survives
them leaving.

### 3. The board-to-repo join is absent on both sides

Darach's mapping skill is explicitly not built. On the Inform side there is no
join at all: IRIS dominates recent commits in the 260MB `Digital solutions team`
repo and appears in **zero** work items and zero vault notes.

### 4. Open questions Darach raised and could not answer

- **Branch management for two engineers on one repo.** No answer offered. The
  Ofgem repo's convention — one dedicated branch per solution connection, never
  main, never a branch someone works on — is a partial answer for solution sync
  but does not address two engineers on the same agent.
- **Where the agent's memory lives** relative to repos and projects.
- **Whether an Excel workbook in the repo is the right UAT vehicle.** He raised
  the doubt himself.

### 5. Two failure modes the proposal does not account for

From the eval work, both would cost a cycle to rediscover:

**Keyword graders are flaky by construction.** Matching is whole-word with no
stemming — `check` does not match `checked` — and the same keyword can pass one
run and fail the next because the agent rephrases. On Late Data, `confirm`
passed against "review and confirm the extracted values" then failed on a rerun
using "confirmation" and "confirmed", with nothing about the agent changed.
Compare-meaning passed both times at 75.

**Multi-turn sets fail silently.** Nothing in the set YAML marks a set as
multi-turn; type is inferred from case kind. One `EvaluationData` case in a
conversational set makes the whole set single-response and every later
expectation disappears from the UI **with no error**.

---

## Recommended actions

**Re-ordered after review.** An earlier draft ordered these by effort against
leverage, which put "write the standard" first. That contradicted this
document's own dependency diagram and its own admission that the mapping skill
is blocked on the ticket question. Dependencies come first, effort second.

### 1. Settle where tickets live, and what a Feature is — Tuesday

Three people hold three models: Darach's tickets-in-repo, Ofgem's
`Agent → Feature → PBI → Feedback`, and Erica's Features-as-the-unit-of-value.
It blocks the mapping skill, it shapes the standard, and it is the only action
here that *is* a meeting — which is the one slot Tuesday actually offers.

Take a proposed answer into the room rather than an open question. Your own
framing was that the session must end in a decision.

### 2. Resolve branch management for two engineers on one repo — Tuesday

Darach flagged this as unsolved and asked the room for help. It is bounded,
engineering-only, cheaper to settle than the ticket question, and it blocks the
two-people-one-repo pattern already live on MOD and Ofgem. It was an open
question in the earlier draft rather than an action; that was an omission.

Ofgem's convention — one dedicated branch per solution connection, never `main`,
never a branch someone works on — is a partial answer worth putting on the table.

### 3. Write the standard from what travels — after 1

Per the split above. Write it to accommodate whichever ticket model wins rather
than hard-coding Ofgem's hierarchy, or you will re-issue it days after
publishing.

### 4. Give IRIS a work item — now, in parallel

No dependencies, costs minutes, and makes the board honest about the largest
active build in the estate. A visible quick win before Thursday.

### 5. Script the eval-set generator — parallel

Independent of the ticket question. The eval document recommends it itself: one
YAML or CSV of intent in, the folder tree out. Half a day, pays off on every
future agent.

### 6. Turn one convention into one policy — later, and as change management

An earlier draft called this "effort: minutes". That measured the Azure DevOps
click-path, not the adoption cost, which is the same error Erica names about
DevOps generally — a mechanism view standing in for a people view.

Of 119 PRs, 41 show a reviewer and it is usually the author. Switching on a
minimum-reviewer policy imposes a new obligation on people who currently review
nothing, in a team you have described as storming rather than forming, with Tom
already fragile and going dark under stress. Sequence it *after* ways of working
lands, so it reads as part of the new operating model rather than a clampdown.

### 7. Pilot measurement — last, but do not lose it

Correctly last, because it needs a defined stream and a settled cycle-time
definition. But it is the only mechanism that would tell you whether the
hypervelocity claim is true rather than anecdotal, so it should not quietly
drop off the list. Start with cycle time on one stream, reusing `AdoCockpit.ts`.

### Still unowned

Three things from the 7 September session have no action against them:

- **The tooling evaluation.** You ruled "Azure DevOps as baseline, then evaluate
  properly." Erica said she cannot decide without numbers. Nobody has been asked
  to produce them, so that commitment currently goes unactioned.
- **Where the agent's memory lives** relative to repos and projects — Darach
  explicitly passed this to you.
- **The certification thread** (AB-100, AI-103, GH-300). Probably right to
  defer, but defer it explicitly rather than letting it vanish.

## Where to work next

```mermaid
flowchart TD
    A["TUESDAY — Darach + Tom + Dom"] --> B{"1. Where do tickets live?<br/>What is a Feature?"}
    A --> B2{"2. Branch management,<br/>two engineers one repo"}
    B --> C["3. Write the standard<br/>from what travels"]
    B --> F["Specify the mapping skill"]
    F --> G["Board-to-repo join"]
    C --> H["THURSDAY — wider team"]
    I["4. IRIS work item"] --> H
    J["5. Eval-set generator"] --> C
    C --> K["6. One policy<br/>as change management"]
    K --> L["7. Cycle time on one stream"]

    style B fill:#451a03,stroke:#f59e0b,color:#fcd34d
    style B2 fill:#451a03,stroke:#f59e0b,color:#fcd34d
    style C fill:#052e16,stroke:#22c55e,color:#86efac
    style I fill:#052e16,stroke:#22c55e,color:#86efac
    style G fill:#0f172a,stroke:#6366f1,color:#a5b4fc
    style K fill:#450a0a,stroke:#ef4444,color:#fca5a5
```

Actions 4 and 5 run in parallel and depend on nothing. Everything else waits on
Tuesday's two decisions.

**Tuesday** is the litmus test with Darach and Tom, and per your own framing it
should end in a decision. The ticket-location question is the one to force,
because everything else is downstream of it.

**Thursday's wider session** can then present a standard drawn from proven
practice rather than a proposal under debate.

**Note on the component library.** My first reading said nothing exists. That was
too harsh: `Ofgem/Agents/system-topic-templates/` holds 11 reusable Copilot
Studio system-topic templates, one file per topic, with a documented
`<PREFIX>` substitution procedure and a warning to diff before pasting because
"pasting blind can revert someone's work". It is a seed, not a library — narrow
to one component type, with no versioning or dependency model — but it is the
shape Darach describes, and it is the natural thing to grow rather than replace.

**Not yet:** the full component library and the bootstrap prompts. Both are real, and
both are premature while the ticket contract is unsettled and nothing is
enforced. Building a library before there is a policy that anyone reuses from it
produces shelfware.

---

### Review

This document was red-teamed on 8 September before release. Four changes
resulted, all of which weakened or complicated the original argument:

1. **The headline was overstated.** "Most of it is already running" became
   "documented and partly evidenced", because only the eval work has an artefact
   of something actually running, and the ALM rollback runbook says outright it
   has never been executed end to end.
2. **The verdict table now grades evidence strength** (● ◐ ○). The original put
   directly-observed artefacts and merely-existing files in the same green
   register, which would have let a reader act on the weakest rows as if they
   were the strongest.
3. **The survivorship-bias objection was upheld** and produced the travels /
   does-not-travel split, since Ofgem is the one process-mature outlier in an
   estate that otherwise has zero pipelines and no review.
4. **Darach was under-credited** and the action order contradicted this
   document's own dependency diagram. Both corrected above.

A separate factual correction came from re-checking the commit record rather
than the review: `Client work` is genuinely shared (Jake 163, Thomas 173), not
single-author as first drafted. The evaluation work specifically is Jake's — 17
of 20 eval commits, 20 to 28 August.

### Scope and limits

Read live from the Azure DevOps API on 2026-09-08. The Ofgem findings come from
that repo's own documentation, which records its own verification dates; **I
have not run any agent, pipeline or eval myself.** The ALM rollback runbook says
plainly that it has never been executed end to end and that a desk review found
parts of it overstated — it is the expected process, not a proven one.

Board figures are from the existing hourly cockpit. Work Items, Release
definitions and Service Connections returned 403 on my token, so backlog
practice and sprint cadence are unverified.
