---
title: Active repos — shape, purpose and how work flows
date: 2026-09-08
type: analysis
tags: [inform, devops, repo-analysis, ways-of-working]
source: Azure DevOps / The-Inform-Team
---

# Active repos — shape, purpose and how work flows

Three repos carry all current activity, and they work in three visibly different
ways: one is a Claude-readable knowledge base with topic branches, one is a
solution monolith with conventional branch naming, and one is a single person
committing straight to main. Nobody reviews anybody else's code anywhere.

> Scope: repos with commits in the last 30 days, from a scan on 2026-09-08.
> Commit samples are capped at 500, so counts on the busiest repos are floors.

## At a glance

| Repo | Last commit | Commits (sampled) | Last 30d | PRs | With reviewers | Owner |
|---|---|---|---|---|---|---|
| PowerPlatform_DEV | 4 Sep | 358 | 25 | 2 (both abandoned) | 0 | Jake Boraston (100%) |
| Client work | 2 Sep | 336 | 125 | 51 | 23 | Jake + Thomas |
| Digital solutions team | 27 Aug | 500+ | 55 | 56 | 11 | Jake (+ automated builds) |

---

## Client work — the knowledge base

**What it is.** Not application code. Its README is explicit: a knowledgebase for
Microsoft 365 and Power Platform delivery, "built to be read and worked in by
Claude Code as much as by people". The agents it describes are configuration in a
client's Power Platform environment; this repo is the record of what that
configuration should be and why.

The structure separates two content types deliberately: *platform guides*
(client-agnostic, transferable — how Copilot Studio source control actually
behaves, which approaches were dead ends) and *worked examples* (real solutions
with the reasoning behind them).

**The `CLAUDE.md` layering is the interesting part.** Files sit at each meaningful
level and load automatically as context. `Ofgem/CLAUDE.md` carries DevOps access
and work-item ordering rules; `Ofgem/Agents/CLAUDE.md` carries agent status, hard
constraints, licensing traps and documented dead ends. The root `CLAUDE.md` is a
writing style guide — British English, contractions, no em dashes, "cut anything
that doesn't earn its place".

This is a deliberate context-engineering pattern, not incidental AI use.

**How work flows.** Topic branches named by domain, merged to main by PR.

```mermaid
flowchart TD
    A["ofgem/* topic branch<br/>one agent or capability"] --> B["PR to main"]
    B --> C{"Reviewer<br/>assigned?"}
    C -->|"usually self, or none"| D["Merge to main"]
    D --> E["Knowledge lands in<br/>CLAUDE.md-layered tree"]
    E --> F["Loaded as context<br/>next time Claude works here"]
    style A fill:#0f172a,stroke:#6366f1,color:#a5b4fc
    style F fill:#052e16,stroke:#22c55e,color:#86efac
    style C fill:#451a03,stroke:#f59e0b,color:#fcd34d
```

Branch naming is domain-scoped and readable: `ofgem/agent-release-notes`,
`ofgem/alm-rollback-review`, `ofgem/azure-devops-connector`,
`skills/writing-review-self-rating`. You can tell what a branch was for from its
name alone, which is not true elsewhere in the estate.

**Caveat on the review figure.** 23 of 51 PRs show a reviewer, but the reviewer
is typically the PR's own author. Self-listing is not peer review. The
substantive count of PRs reviewed by a *second person* is close to zero.

**Cadence.** 21 commits in July, 302 in August, 13 so far in September. August was
a concentrated build.

---

## Digital solutions team — the solution monolith

**What it is.** The 260MB centre of gravity: Dynamics solutions, canvas app
exports, ERD, PowerShell operational scripts (`Get-DataverseFlowErrors.ps1`,
`Get-FlowError.ps1`, `Get-LeaveApprovalIds.ps1`), pipeline YAML for
sandbox-to-source and DEV-to-source flows, plus an `AppGraveyard` and a
`FLOW_ERROR_TRIAGE.md` runbook.

It carries both `CLAUDE.md` and `GEMINI.md`, so more than one assistant has been
pointed at it.

**How work flows.** This one has the clearest convention in the estate.

```mermaid
flowchart TD
    A["feat/* or fix/* branch"] --> B["PR to main"]
    B --> C["Merge, no reviewer"]
    C --> D["Automatic Build<br/>17 pipeline commits"]
    D --> E["Dynamics-Solutions/<br/>solution artefacts"]
    F["Sandbox / DEV environment"] -.->|"export YAML pipelines"| E
    style A fill:#0f172a,stroke:#6366f1,color:#a5b4fc
    style D fill:#172554,stroke:#3b82f6,color:#93c5fd
    style E fill:#052e16,stroke:#22c55e,color:#86efac
```

Branches follow conventional-commit style: `feat/iris-people-export`,
`fix/contract-line-manager`, `fix/iris-route-chunk-recovery`. A product called
IRIS dominates recent work. Only 11 of 56 PRs carry any reviewer.

**Cadence.** Steady across the year with a July peak: Feb 23, Mar 46, Apr 101,
May 86, Jun 52, Jul 135, Aug 57. This is the repo that never stops.

---

## PowerPlatform_DEV — the solo delivery repo

**What it is.** Solutions and documentation with a `CBC-Capacity-Seed-Prompt.md`
and `CBC-Delivery-Progress.md` at root, plus an `.obsidian` folder — someone
opens this repo as an Obsidian vault.

**How work flows.** It mostly doesn't, in process terms.

```mermaid
flowchart TD
    A["Direct commits to main"] --> B["main"]
    C["fix/task-links-prod<br/>PR #126"] -.->|"abandoned"| B
    D["flow-fix/pr-plumbing-test<br/>PR #79"] -.->|"abandoned"| B
    style A fill:#450a0a,stroke:#ef4444,color:#fca5a5
    style B fill:#052e16,stroke:#22c55e,color:#86efac
```

358 commits from one person, and the only two PRs ever raised were both
**abandoned** — one of them named `pr-plumbing-test`, which reads like an
experiment in whether PRs were worth using here. The answer taken was no.

**Cadence.** June 246, July 85, August 12, September 15. A large build in June
that has since settled into maintenance.

---

## What changed recently, and what it says

```mermaid
gantt
    title Commit activity across the active repos (2026)
    dateFormat YYYY-MM-DD
    axisFormat %b
    section Digital solutions team
    Steady, July peak       :2026-02-10, 2026-08-27
    section PowerPlatform_DEV
    June build              :2026-06-11, 2026-07-31
    Maintenance             :2026-08-01, 2026-09-04
    section Client work
    Ramp                    :2026-07-29, 2026-07-31
    August build            :2026-08-01, 2026-09-02
```

Three observations worth carrying forward.

**The newest repo is the most process-mature.** `Client work` began in late July
and arrived with domain-scoped branches, a written house style, and layered
context files. The older repos have looser conventions. Whatever practice is
being established, it is being established here.

**Agent-assisted development is settled practice, not an experiment.** Four
repos carry `CLAUDE.md` or `.claude/`; one also carries `GEMINI.md`. In
`Client work` the repo's *entire structure* is designed around what a model
loads as context. Any proposal that treats AI assistance as new would be
arguing a point already won.

**Review is the consistent gap.** Across 109 PRs in these three repos, peer
review by a second person is essentially absent. Branch discipline exists;
the checkpoint it normally feeds does not.
