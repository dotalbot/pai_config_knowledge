---
title: Evaluation and QA — what Client work already solved, and how it meets Darach's proposal
date: 2026-09-08
type: analysis
tags: [inform, devops, evaluations, qa, uat, copilot-studio, ways-of-working]
source: Azure DevOps / Client work repo + Darach engineering proposal 7 Sept
---

# Evaluation and QA — what Client work already solved

Darach's proposal separates deterministic testing (unit tests) from probabilistic
testing (evals) and asks how to produce automated evidence for both. **The
probabilistic half is already built and running in `Client work`**, with test
sets held as version-controlled solution source and timestamped result exports
sitting beside them. The two approaches are complementary, not competing: his
Excel register is the human UAT instrument, the eval sets are the machine one.

> Evidence: `Ofgem/Agents/evaluation-test-sets-as-source.md`, the `evaluation/`
> folders under FITEnquiriesResponder, EEInsightsReporting and LateDataAgent,
> and `Ofgem/Agents/scripts/New-EvalSet.ps1`. Cross-referenced against
> `Meetings/Darach engineering methods proposal - 7 Sept 2026/`.

## How the two halves fit

```mermaid
flowchart TD
    subgraph DEV["DURING DEVELOPMENT — machine"]
        S["Eval sets as solution source<br/>YAML in botcomponents/"]
        S --> R["Run in Copilot Studio"]
        R --> C["results-YYMMDD-HHMM-baseline.csv<br/>per-grader result + explanation"]
        C --> S
    end
    subgraph GATE["RELEASE GATE"]
        G{"Baseline holds?"}
    end
    subgraph UAT["FORMAL UAT — human"]
        X["Darach's Excel register<br/>19 click-through tests<br/>feature checks, sign-off"]
        X --> T["Traceability to repo tickets"]
    end
    C --> G
    G -->|"pass"| X
    G -->|"regression"| S
    T --> D["Defects back to tickets"]

    style S fill:#052e16,stroke:#22c55e,color:#86efac
    style C fill:#052e16,stroke:#22c55e,color:#86efac
    style X fill:#172554,stroke:#3b82f6,color:#93c5fd
    style G fill:#451a03,stroke:#f59e0b,color:#fcd34d
```

Darach's stated aim is that UAT testers surface business objections rather than
defects. Evals are the mechanism that makes that true for agent behaviour: run
them during development, hold a dated baseline, and only open UAT when it still
passes.

| | Deterministic | Probabilistic |
|---|---|---|
| **What** | Flows, calculations, data shape | Agent responses, tool choice |
| **Instrument** | Unit tests, PowerShell, Playwright | Copilot Studio evaluation sets |
| **Evidence** | Pass/fail | Per-grader result, score, explanation |
| **Lives** | Repo | Repo, as solution components |
| **Status at Inform** | Proposed (Darach) | **Built and running (Ofgem)** |

## The finding that matters: evals are source, not CSV

Test sets export as ordinary botcomponents with YAML bodies. A set is
`componenttype` **19**, category Testing, body `kind: EvaluationSet` holding the
graders. Each case is also componenttype 19, `kind: EvaluationData`, linked by
`parentbotcomponentid`.

**Everything the CSV route loses is expressible in the YAML:**

| | CSV import | Solution source |
|---|---|---|
| Question and expected response | yes | yes |
| Which graders the set uses | no — reconfigure every import | yes |
| Compare-meaning threshold | no | yes |
| Per-case keywords | no — one at a time in the UI | yes |
| Expected tool or topic call | **not expressible at all** | yes |
| Reviewable diff | no | yes |
| Travels with the solution | only via Add required objects | yes, it is a component |

On the FIT agent that was 19 cases of keywords plus three sets of grader config,
all clicked in by hand. As source it is one file per case and a pack.

**Asserting behaviour, not just wording.** `ExpectedToolCallStep` asserts the
agent actually called a named action:

```yaml
expectedExecutionSteps:
  - kind: ExpectedToolCallStep
    schemaName: og_FITEnquiriesResponder.action.Office365Outlook-Draftanemailmessage
```

`ExpectedTopicTriggeredStep` does the same for a topic. This is the part that
makes evals a real gate rather than a text-similarity check.

Verified both directions: read from a real client export
(`FITEnquiriesResponder_1_0_0_60604.zip`, 28 Aug 2026, three sets and 19 cases),
and proven by creating a set from scratch into Dataverse and reading it back
byte for byte. Script: `scripts/New-EvalSet.ps1`.

## The grader vocabulary

The YAML `kind` does not match the UI label, which is why this mapping is worth
keeping:

| UI test method | YAML grader kind | Config |
|---|---|---|
| General quality | `GeneralQualityGrader` | none |
| Compare meaning | `CompareMeaningGrader` | `threshold: 0.7` (0–1, not 0–100) |
| Keyword match, All | `ContainsAllGrader` | per case, `expectedKeywords` |
| Keyword match, Any | `ContainsAnyGrader` | per case, `expectedKeywords` |
| Tool use | `ToolCallGrader` | per case, `expectedExecutionSteps` |
| Custom | `PromptGrader` | `name`, `instructions`, `labels` with Pass/Fail outcomes |

The Any/All toggle is not a property — it swaps the grader kind itself.

## What automated evidence actually looks like

`FITEnquiriesResponder/evaluation/results-260827-1532-baseline.csv`, named by
run timestamp, columns:

```
conversationId, question, expectedResponse, actualResponse,
testMethodType_1, result_1, passingScore_1, explanation_1,
testMethodType_2, result_2, passingScore_2, explanation_2
```

Per case: the conversation ID, what was asked, what was expected, what the agent
actually said, and for each grader its type, result, passing score and a written
explanation. Committed alongside the source that produced it.

Three named sets on FIT: **scope and safety**, **knowledge gap**, **drafting**.
Set definitions also exist as JSON for Late Data and EE Insights.

**This is the artefact Darach's register needs feeding into it.** His Excel
workbook holds cases, deterministic runs, eval runs, defects and sign-off joined
by stable IDs. The eval CSV is the eval-runs half, already produced in the right
shape, with an explanation column a human can read during sign-off.

## Two failure modes that would otherwise cost a cycle

**Keyword matching is whole-word, with no stemming or prefix matching.** `check`
does not match `checked`; `dash` does not match `dashes`. Both fail with "No
keywords found" while reading as obviously present.

**Worse, the same keyword can pass one run and fail the next**, because the agent
rephrases. On Late Data, 28 Aug 2026, `confirm` passed against "review and
confirm the extracted values", then failed on a rerun whose response used only
"confirmation" and "confirmed". Compare meaning passed both times at 75. Nothing
about the agent changed.

> A bare stem is a coin flip.

Mitigations recorded: prefer nouns the agent cannot inflect (`template`,
`branding`, `human`, `line manager`), or switch to Keyword match Any and list
every form. And author keywords **from a real run** — run the set, export the
results, take the words verbatim out of `actualResponse`.

**Multi-turn sets fail silently.** Nothing in the set YAML marks a set as
multi-turn; the type is inferred from the `kind` of its cases. An
`EvaluationData` case in a set meant to be conversational silently makes the
whole set single-response, and every expectation on a later row disappears from
the UI **with no error**. Conversation cases are `MultiTurnEvaluationCase`, have
no `expectedOutput` at all (compare-meaning is unavailable), and expectations
sit at case level rather than per turn. Caps: 20 cases, 12 messages, each
activity counting as one message.

**Topic schema names can be meaningless.** The knowledge-gap topic displays as
"Report a FIT knowledge gap" but its schema name is
`og_FITEnquiriesResponder.topic.Untitled`, because it was created before being
named — and renaming in the UI does not rename the schema. Any
`ExpectedTopicTriggeredStep` must use the schema name read from the export.

## The documented workflow

1. Export the agent solution once to get real schema names for tools and topics.
   Assertions reference them exactly and they are not guessable.
2. Generate the `mspva_<guid>` folder pair per set and per case. Any GUID works
   on first import; it becomes the identity, so keep it stable or you create
   duplicates.
3. Add every new folder to `[Content_Types].xml` — a missing entry fails the
   import.
4. Pack and import to DEV.
5. Run, then export again to confirm the round trip before trusting the pattern.

The document's own recommendation: **script a generator** — one YAML or CSV of
intent in, the folder tree out — turning "write 20 test cases" into editing one
file. That is a concrete, small piece of work with a clear payoff.

## What to leverage

**Adopt the source-not-CSV pattern as the house standard.** It is proven both
directions on a real client solution, it is the only way to assert tool calls,
and it makes evals reviewable in a PR like anything else.

**Feed the eval CSV into Darach's register rather than duplicating it.** The
columns already carry a per-grader explanation, which is what a human sign-off
needs. Joining on `conversationId` plus case ID gives the traceability his
proposal asks for.

**Carry the two failure modes into the standard.** Keyword flakiness and silent
multi-turn voiding are exactly the kind of thing that gets rediscovered
expensively. They belong wherever the team's engineering standard ends up
living, alongside `Copilot Studio Build Caveats.md`, which is already written
for a coding agent to read before proposing a fix.

**Note the scope limit.** All of this is Copilot Studio evaluation. It covers
agent behaviour, not the deterministic flows, Dataverse schema or UI, which is
where Darach's Playwright and PowerShell proposal does the work. The two are
genuinely complementary and neither replaces the other.

---

### Provenance

Read live from the `Client work` repo on 2026-09-08 via the Azure DevOps API.
Quoted findings and figures are from `evaluation-test-sets-as-source.md`, which
records its own verification dates (28 Aug 2026) and the export it was derived
from. Darach's side is from the 7 Sept transcript and deck, filed under
`Meetings/`. Nothing here has been verified against a live agent run by me.
