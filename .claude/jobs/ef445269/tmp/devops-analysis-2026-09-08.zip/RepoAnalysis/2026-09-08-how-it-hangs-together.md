---
title: How it hangs together — strategy, boards, repos, delivery
date: 2026-09-08
type: analysis
tags: [inform, devops, repo-analysis, boards, strategy, ways-of-working]
source: Azure DevOps + Cockpit notes + repo analysis
---

# How it hangs together — strategy, boards, repos, delivery

The four layers do not connect. Strategy is being written, the board holds 398
open items, the repos hold real work, and there is no mechanism joining any of
them: **IRIS, the product dominating your busiest repo, appears nowhere on the
board or in the vault.** The DevOps anchoring ambition is sound, and it is not
yet true.

## The whole picture

```mermaid
flowchart TD
    subgraph L1["1 · NORTH STAR"]
        FF["Frontier Firm — six capability points<br/>defined 1 Sept<br/><b>no work item exists</b>"]
    end
    subgraph L2["2 · STRATEGY"]
        AS["ADO 17520 — AI strategy and roadmap<br/>Steve, due end Sept<br/><i>the acknowledged gap</i>"]
    end
    subgraph L3["3 · BOARD — 398 open, 469 legacy"]
        BAU["BAU · 233<br/>83% moving"]
        CD["Client deliverables · 64<br/>Archie, weekly"]
        GTM["GTM + capability · 60<br/><b>11 Products, 0 owners<br/>untouched since 6 July</b>"]
        REST["Value · Service design<br/>Customer zero · AI+Copilot<br/>26 items, mostly still"]
    end
    subgraph L4["4 · REPOS — 17, three live"]
        CW["Client work<br/>Ofgem agents, knowledge base"]
        DST["Digital solutions team<br/><b>IRIS — not on the board</b>"]
        PPD["PowerPlatform_DEV<br/>solo, direct to main"]
    end
    subgraph L5["5 · DELIVERY"]
        ENV["Power Platform environments"]
    end

    FF -.->|"no trace"| AS
    AS -.->|"does not exist yet"| GTM
    CD ==>|"Ofgem: Client → SoW → Feature<br/>the one real chain"| CW
    GTM -.->|"catalogue never started"| DST
    DST -.->|"IRIS has no work item"| ENV
    CW --> ENV
    PPD -.->|"no pipeline<br/>manual export"| ENV

    style FF fill:#2e1065,stroke:#7c3aed,color:#c4b5fd
    style AS fill:#451a03,stroke:#f59e0b,color:#fcd34d
    style GTM fill:#450a0a,stroke:#ef4444,color:#fca5a5
    style DST fill:#450a0a,stroke:#ef4444,color:#fca5a5
    style CD fill:#052e16,stroke:#22c55e,color:#86efac
    style CW fill:#052e16,stroke:#22c55e,color:#86efac
```

Solid arrows are real traces. Dotted arrows are the breaks.

## Layer by layer

| Layer | What it holds | State |
|---|---|---|
| **North Star** | Frontier Firm, six capability points | Defined 1 Sept. No work item — an open decision, not an oversight |
| **Strategy** | ADO 17520, Steve, end Sept | The known absent layer. Everything below proceeds without it |
| **Board** | 398 open / 469 legacy, 8 streams | 43% unowned. Two streams live, four nearly still |
| **Repos** | 17, three live | Two people own everything. No pipelines, no review gate |
| **Delivery** | Power Platform environments | Reached by hand. YAML exists with `trigger: none` |

## The one chain that works

Ofgem is the exception that proves the rule:

```mermaid
flowchart LR
    C["17281 Ofgem<br/>Client"] --> S["17405 / 17406<br/>Statement of Work"]
    S --> F["D&S Features<br/>Archie Clark, weekly"]
    F --> R["Client work repo<br/>ofgem/* branches"]
    R --> E["Client environment"]
    style C fill:#052e16,stroke:#22c55e,color:#86efac
    style R fill:#052e16,stroke:#22c55e,color:#86efac
```

Client → SoW → Feature → branch → environment. Every step is visible, and the
branch names (`ofgem/agent-release-notes`, `ofgem/alm-rollback-review`) make the
join legible without any tooling. **This is what "anchored in DevOps" looks like
when it works, and it exists exactly once.**

## The three breaks

**Break 1 — the service catalogue was never started.** GTM and capability build
holds 11 Products created 6-7 July: AI acceleration and CoE design, Agent 365
Governance, Champions Networks, Evergreen Service, Prompt-a-thons, End-to-End
Power Platform Delivery. **Every one is unowned, state New, untouched for two
months.** This is the department's own offer catalogue, written down and then
left. It is also precisely the capability layer the strategy is meant to
describe — so the strategy has no delivery evidence to point at.

**Break 2 — the busiest code has no board presence.** `Digital solutions team`
is the 260MB centre of gravity, and its recent commits are dominated by IRIS:
`feat/iris-people-export`, `fix/iris-route-chunk-recovery`,
`iris-work-iq-assistant`, `iris-planner-leave-improvements`. IRIS appears in
**zero** work items and **zero** vault notes. Someone is building a product
that the board does not know exists.

**Break 3 — nothing enforces the join.** No pipelines, one branch policy (file
size), no build validation, no work-item linking on PRs. Even where a developer
wanted to connect a commit to an item, nothing asks them to.

```mermaid
flowchart LR
    W["Work item"] -.->|"no linking policy"| B["Branch"]
    B --> P["PR"]
    P -.->|"no reviewer policy"| M["main"]
    M -.->|"no pipeline trigger"| D["Environment"]
    style W fill:#0f172a,stroke:#6366f1,color:#a5b4fc
    style D fill:#052e16,stroke:#22c55e,color:#86efac
```

## What this means for the strategy

Your stated goal is that every claim traces to a work item, with missing items
introduced. Measured against that:

**The trace works for client delivery and nowhere else.** Ofgem has the full
chain. BAU moves but is operational rather than strategic. Everything the
strategy actually wants to talk about — capability build, GTM, Customer Zero —
is either unowned, unstarted, or invisible.

**The gap is not knowledge, it is ownership.** These 11 Products are already
named and already written down. Nothing is missing except a person against each
one. That is a decision, not an analysis.

**Two candidate first moves**, both small:

1. **Give IRIS a work item.** The largest active build in the estate is
   untracked. One Product item with an owner makes the board honest about what
   is actually being delivered.
2. **Own or close the 11 July Products.** Two months untouched and unowned is a
   catalogue nobody has committed to. Each either gets a name against it or
   moves to legacy alongside the other 469.

Neither needs the AI strategy to land first, which is the point: both are
available now, and both make the eventual strategy provably traceable rather
than aspirationally so.

---

### Provenance and limits

Board figures from `~/obsidian/02 Doing/Cockpit/DevOps Roadmap.md` and
`Digital NEST.md`, generated by `LIFEOS/TOOLS/AdoCockpit.ts` at 2026-09-08 10:21.
Repo figures from `RepoAnalysis/2026-09-08-cross-repo.md`.

The IRIS finding rests on absence from the cockpit output and the vault, both
searched. Following the evidence rule already recorded in memory: this supports
**"not located in the board or vault as rendered"**, not "does not exist
anywhere in Azure DevOps". A direct work-item API query would settle it — my
PAT lacks Work Items scope, though `AdoCockpit.ts` has it.

No cadence analysis here: cycle time, lead time and created-versus-closed rates
over time remain unmeasured, and would be the natural next piece.
