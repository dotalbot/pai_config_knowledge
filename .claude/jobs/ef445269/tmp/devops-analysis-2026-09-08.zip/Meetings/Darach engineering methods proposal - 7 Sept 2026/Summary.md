---
title: Darach — Engineering Delivery proposal, 7 September 2026
date: 2026-09-07
type: meeting
subtype: proposal
attendees: [Darach Sharkey, Dom, Erica Jefferies, Tom, Srabani, Jake]
duration: 62 min
tags: [inform, digital, engineering, ways-of-working, devops, jira, github, ai-assisted-delivery]
---

# Darach — Engineering Delivery proposal, 7 September 2026

Darach presents how he has been working — an AI-assisted delivery harness with
the ticketing system baked into the repository — and proposes it as a formalised
team approach. Explicitly framed as food for thought, not a decision: "this isn't
me saying we should do this."

> Transcript: `Transcript.md`. Deck: `Inform_Digital_Team_Engineering_Delivery_Proposal.pptx`
> (16 slides, Darach Sharkey, September 2026).

## Dom's ruling on how to proceed

The one decision actually taken. Establish engineering principles first, stay on
Azure DevOps as the baseline, then evaluate tooling properly:

> "Let's get clear on how we're going to operate projects, development, the
> development tools that we're going to use... so we've got a baseline and we're
> working from something."

With a warning against half-measures: **"You can't be half pregnant. Having a
little bit of this and a little bit of that is far more damaging than sticking
to one, let it be whatever that decision might be."**

## The proposal

**The core idea: tickets live in the repo, not the board.** The agent's memory
is the repository's own ticket system, so context, dependencies and progress
travel with the code. A developer clones, runs Claude, and the agent knows the
state — "It doesn't need to reference DevOps because the tickets are in the repo."

**Two prompts establish a project.** The *bridgehead* prompt (a few thousand
lines) sets up MCP servers, security model, ALM practice and component-library
access in an empty folder, with no knowledge of the client. The *project
bootstrap* then trims irrelevant tools, inspects any existing repo, and proves
the toolchain by spinning up and pulling back a solution. A third *pruning*
prompt is in progress for phase transitions.

**The bucket.** Anything relevant — client transcripts, failed UAT results, bug
notes — gets dropped in a folder; the agent indexes it, works out what it is,
archives it and attaches it to the right tickets.

**Model routing matters for cost.** Learned the hard way: an unrouted setup
"deployed 50 versions of Fable" and consumed his personal credits in 15 minutes.

**QA moves before UAT.** Background PowerShell tests, tightly scoped browser
access that logs in and clicks through taking screenshots, plus Playwright
scripts. The aim: "we really don't want to be relying on our UAT groups to be
spotting bugs" — UAT should surface business objections, not defects. UAT
evidence lives in an Excel workbook inside the repo, shared with the client;
when a tester updates it, Claude sees the change and links it to the ticket.
Currently running this way on MOD.

**Deterministic vs probabilistic testing.** Anything touching AI stops being
deterministic. Unit tests for deterministic solutions, **evals** for
probabilistic ones, with a defined threshold for what percentage passes before
production — and the client educated on that distinction early.

**Keeping the business in the loop.** A mapping skill (not yet built) would
translate technical repo tickets into PM-facing Epics, Stories, Bugs and Tasks,
pushed to Azure DevOps via MCP. Ownership must be preserved per-ticket, not
per-repo, so Srabani knows who actually did the work.

## The deck, in brief

| Slide | Content |
|---|---|
| 2 | Frontier Firm ambition; hypervelocity defined as shorter time to validated outcomes, human accountability at release gates, reusable knowledge, assist → collaborate → delegate |
| 3 | The bridgehead: inspect the ground, establish the harness, prove one small slice |
| 4 | The two bootstrap prompts, with excerpts |
| 5 | Harness structure (adapted from Matt Pocock and open agent standards): AGENTS.md as operating contract, CONTEXT.md and ADRs, skills loaded only when relevant, enforceable boundaries |
| 6 | Wayfinder, Grill with Docs, bounded loops |
| 7 | Continuity travels with the code — tickets, session handovers, `docs/control/NEXT_ACTION.md`; "make resumption boring" |
| 8 | VS Code as the single workspace connecting Copilot Studio, PAC CLI, Dataverse, release pipeline |
| 9 | Governed component library across Knowledge, Tools, Security, Dataverse |
| 10-12 | QA before UAT; unit tests vs evals; one linked test register with stable IDs joining workbook to Git |
| 13 | Mapping skill + Azure DevOps MCP to keep the business in the loop |
| 14 | **Work boards: Azure DevOps by default** (Jira where PMs already use Atlassian; GitHub Projects for developer-led delivery) |
| 15 | Repositories: Azure Repos as coherent default; GitHub strong for Copilot and Actions |
| 16 | Approve a measurable pilot: one vertical slice, test the handover, measure lead time / rework / escaped defects / reuse / handover time |

**Note the divergence.** The deck recommends Azure DevOps by default. The room
argued the opposite way.

## The tooling debate

**Erica wants Jira.** Twenty years of DevOps and "I still hate it." Her
objection is not technical but adoption: "Every time I show a DevOps board, I
literally see everything glaze over." She wants something stakeholder-facing
that marketing and creative would actually use, and notes some clients use Jira
so there's a learning case. Her condition: it must keep "an auditable pipeline
from requirements to done."

**Tom is unconvinced.** Creative already use DevOps without complaint. "If
DevOps is set up right and customized in the right way, then it's very
powerful." Raises licensing cost for Jira and GitHub Enterprise, and sees no
technical benefit over Azure DevOps today. Already holds the org names —
`theinformteam` on GitHub, and a Jira/Confluence playground.

**Srabani defends DevOps on flow metrics** — cycle time, predictability,
quality, happiness — arguing they beat what Jira offers out of the box. Erica
counters that the analytics add-on they used with Jira was better, and that she
never got flow metrics working properly in DevOps.

**Erica's framing on cost:** she owns the budget and wants an educated decision,
not avoidance. "I can't make any decisions based on no numbers." Dom's estimate
in the room was around £20/month.

**Erica on velocity, worth recording:** velocity has a bad name because it
"creates an anti-pattern in devs and product managers by forcing speed over
quality." Mature agile teams measure **cycle time**, not velocity. Also raised
Monte Carlo forecasting for answering "when do I get my thing".

**Both Darach and Erica agree on the implementation risk:** don't build the car
while driving it. Darach: the biggest danger is a "Frankenstein's monster"
created by adopting a tool while still designing the process. Erica: "keep it
simple to start with and build on it."

## Certification thread

Darach proposes the Microsoft **Frontier Transformation Engineer** badge, three
exams: **AB-100** (architectural full-stack, low-code, D365 awareness — useful
for migrating clients off legacy D365), **AI-103** (pro-code and Azure
extensibility for when low-code runs out), **GH-300** (agentic-assisted coding).
Commercial argument: competitors sell this badge, so it signals parity.

## Open questions

- **Branch management for two engineers on one repo.** Darach has no answer:
  "That's something I would need a bit more time to think about."
- **Where the agent's memory lives** relative to repos and projects — explicitly
  flagged as a question for Dom.
- **Whether an Excel workbook in the repo is the right UAT vehicle** — Darach
  raises it himself as possibly not the best solution.
- **Ofgem comparison.** Dom asked Tom and Jake what they do for UAT there, and
  how close they are to it. Left unanswered, deliberately parked.
- **The mapping skill is not built yet**, so the repo-to-board bridge is a
  proposal, not a working mechanism.
- **Dead time** — Dom pushed on the definition twice. Settled loosely as time
  wasted mid-delivery solving something discovery missed, not bench time.

## Bearing on the repo and board analysis

Direct connections to `RepoAnalysis/2026-09-08-how-it-hangs-together.md`:

1. **This proposal would formalise what the repos already show.** 12 of 16
   active repos carry `CLAUDE.md` or `.claude/`; `Client work` is explicitly
   built for Claude Code to read. Darach is proposing the standard for a
   practice already in use — which is why it reads as a formalisation rather
   than a change.
2. **It answers the "no pipelines, no gates" finding, partly.** Release
   pipeline, branch policies and human gates all appear in the deck. None exist
   in the org today: zero build definitions, one branch policy (file size).
3. **The mapping skill is precisely the missing join.** The analysis found board
   and repo work unconnected, with IRIS invisible to the board. Darach's
   repo-tickets-to-DevOps-via-MCP bridge is the mechanism that would close it —
   and it is the piece not yet built.
4. **Erica's Feature-as-unit-of-value rule (from her 1:1 the same day) and this
   proposal need reconciling.** If tickets live in the repo and only distilled
   items reach the board, then what appears as a Feature — and who decides the
   granularity — becomes the contract between engineering and PM.
