---
title: Dom and Erica 1:1 — 7 September 2026
date: 2026-09-07
type: meeting
attendees: [Dom, Erica Jefferies]
duration: 32 min
tags: [inform, digital, ways-of-working, devops, team-structure]
---

# Dom and Erica 1:1 — 7 September 2026

Erica hands Dom ownership of the department's structure and ways of working, and
asks him to be the one who presents it to the team. The week's goal is to get
team structure agreed and deployed, litmus-tested with Darragh and Tom on
Tuesday, shared wider on Thursday.

> Transcript: `Transcript.md` in this folder.

## Decisions

| Decision | Detail |
|---|---|
| **Dom owns ways of working** | Structure, team shape and DevOps operating model. Erica explicitly stepping back: "I need to start getting out of the way rather than getting in the way." |
| **Dom presents it to the team** | Not Erica. Her reasoning: the team won't trust structural direction from her because "historically it's not my bag", but they will from Dom. |
| **Litmus test Tuesday** | With Darragh and Tom, in London. Dom's framing: the conversation must end in a decision, not another discussion. |
| **Wider team session Thursday** | Placeholder to be booked, ~1pm (Seán unavailable from 2:30, school run). Titled "wider digital team ways of working". |
| **Srabani gets DevOps operating detail** | Erica briefs her, then delegates board work to Srabani, Dom and Steve rather than doing it herself. |
| **TypeScript as the default language** | Dom's view on the Darragh/Tom disagreement: "Darragh's right and Tom's wrong" — the argument for a disparate language loses to the default everyone else uses. To be settled Tuesday. |

## The DevOps thread

This is the part that connects to the repo and board analysis.

**Erica's read on the board:** "it's in good shape. It just needs stuff in there
— the structure's there. It just hasn't got anything in it to show how it's going
to operate." Her design intent, stated plainly:

- Separate backlogs per team, separate access, separate stakeholders
- **Features are the unit of value and prioritisation.** "We don't want to see
  the everyday PBIs and work. That's just the team doing their stuff. But the
  features are essentially what we prioritise and what the team should be
  working on."
- One place to see all features across those separate backlogs

**Dom's condition:** shared vocabulary first. Nobody currently has a clear
definition of Product Family vs Product vs Feature. He wants a diagram that
fixes the meaning of each level before the structure is rolled out — Erica
specifically asked for one of his drawings to carry it.

**The operating rule Dom proposes:** every meeting updates the board. "If we're
going to talk about something today in a meeting, then there's got to be an
update on the DevOps board because we're doing something that's related to an
item, or we're adding an item." That is the anchoring mechanism stated as a
behaviour rather than a tool.

**Ceremony to establish this week:** an engineering daily check-in, plus a
defined cadence for Steve's strategy work — what his features are and how often
they move.

## People

**Tom.** Fragile and frustrated rather than burnt out. Covering Seán's work plus
support through August. The website is his trigger — marketing shipped something
he had already flagged as not good enough, and his objection was public enough
to read as an attack on Lindsay, so the message was lost. Erica is steering him
away from it deliberately; he doesn't know that. His anti-pattern is going dark
under stress — still working, but unreachable. Steve to reset expectations
without calling him out. Positive on Ofgem.

**Erica on herself.** Her ideas get rejected, then adopted years later when
someone else proposes them; she stops fighting for them. Current blocker is
pushback on everything, plus pressure from Sam and Emma on commitments already
made. She raised the AI strategy meeting where Tom asked at 10pm what the meeting
was for as the specific frustration.

**Dom's counter:** the fix is forethought and agenda discipline, and the team is
storming rather than forming. Jake, Tom and Darragh want "little boxes to put
things in" by nature, and will produce well once the structure gives them that.

**The working agreement.** Erica wants Dom to tell her directly when she should
step out of the weeds; she'll tell him when she's under pressure, since the
symptom is last-minute meetings with no agenda. Dom's commitment: any grumbling
happens privately, never in front of the team.

## Open

- **Venue for Tuesday** — London, central-ish. ADS co-working is free but
  awkwardly placed for Dom.
- **Seán** — keen on the backlog, needs DevOps 101 and patience. Dom: "five
  percent more activity from him is better than no activity."
- **Home of materials** — the team uses a wiki that only they can read, against
  a stated aim of a public shop window. Unresolved: what stays internal, and how
  something moves from wiki to published.

## Bearing on the repo and board analysis

Three direct connections to `RepoAnalysis/2026-09-08-how-it-hangs-together.md`:

1. **Erica's "the structure's there, it just hasn't got anything in it" matches
   the finding exactly** — 11 Products in GTM and capability build, created 6-7
   July, all unowned and untouched. The container exists; nothing was put in it.
2. **The Feature-as-unit-of-value rule is the missing join.** If Features are
   what get prioritised and tracked, then IRIS — dominating commits in the
   largest repo with no work item anywhere — is invisible to the very layer
   Erica intends to steer by.
3. **The vocabulary gap Dom names is real and already measured.** `Digital
   NEST.md` derived the hierarchy empirically from data (Client → SoW → Feature
   → PBI → Task) because the process template doesn't state it, and found 17 of
   65 items parented outside the area path they appear in.
